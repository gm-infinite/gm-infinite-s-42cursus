/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client_bonus.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kuzyilma <kuzyilma@student.42istanbul.c    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/06 13:29:25 by kuzyilma          #+#    #+#             */
/*   Updated: 2024/12/13 11:27:33 by kuzyilma         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk_bonus.h"

static t_client_needs	g_client;

void	error_message(void)
{
	ft_printf("\e[37;31m[ERROR]\e[0m kill returned -1\n \
*probably server pid is wrong*\n");
	exit(0);
}

void	signal_handler(int signum, siginfo_t *info, void *ucontext)
{
	int	bit;
	int	error;

	(void) info;
	(void) ucontext;
	if (signum == SIGUSR2)
	{
		ft_printf("\e[32m[INFO]\e[0m all of the message succsessfuly sent\n");
		exit(0);
	}
	bit = (((unsigned char)g_client.message[g_client.char_count]) >> \
	(7 - g_client.bit_count)) % 2;
	if (bit == 1)
		error = kill(g_client.pid, SIGUSR2);
	else
		error = kill(g_client.pid, SIGUSR1);
	if (error == -1)
		error_message();
	(g_client).bit_count++;
	if (g_client.bit_count == 8)
	{
		g_client.char_count++;
		g_client.bit_count = 0;
	}
}

int	main(int argc, char **argv)
{
	struct sigaction	sa;

	if (argc != 3)
	{
		if (argc < 3)
			ft_printf("\e[37;31m[ERROR]\e[0m not enough arguments\n");
		if (argc > 3)
			ft_printf("\e[37;31m[ERROR]\e[0m too many arguments\n");
		ft_printf("\e[0mUSAGE: ./client <server_pid> <string>\n");
		return (1);
	}
	sa.sa_flags = SA_SIGINFO;
	sa.sa_sigaction = signal_handler;
	sigemptyset(&sa.sa_mask);
	sigaction(SIGUSR1, &sa, NULL);
	sigaction(SIGUSR2, &sa, NULL);
	g_client.pid = ft_atoi(argv[1]);
	g_client.message = argv[2];
	signal_handler(SIGUSR1, NULL, NULL);
	while (1)
		pause();
}
